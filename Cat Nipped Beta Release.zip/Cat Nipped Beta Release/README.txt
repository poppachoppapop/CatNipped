WASD Keys to move.
Arrow Keys to shoot.
'E' to interact with NPCs.
'F' to use the freeze ability.
SHIFT key to dash.
SPACEBAR to use AOE rock attack.
'P' for pause menu.